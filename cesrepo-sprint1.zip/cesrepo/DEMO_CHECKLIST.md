# Deliverable 2 live demo

1. Follow README's production startup commands and open http://localhost:5001.
2. Show six Now Showing and four Coming Soon movies. Point out titles, posters, ratings, genres and card showtimes.
3. Explain that `backend/server.js` queries SQLite; `movies.status` distinguishes categories and a fresh DB seeds ten movies. If demonstrating a DB edit, use a disposable database and reload the page to show the changed value.
4. Search `uNe` to demonstrate case-insensitive partial title matching. Clear the search to restore the catalog.
5. Select Action: four movies appear. Combine it with `Dune` to show no matches. Clear both controls. Show that date filtering is visible but intentionally disabled for this sprint.
6. Select Dune. Show its actual poster, title, MPAA rating, genre, cast, director, synopsis and three sample showtimes.
7. Scroll to the embedded trailer and press Play. Confirm moving video and audio on the actual demo network. Repeat with another movie if desired.
8. Click Book 5:00 PM. Verify the booking header matches the chosen movie and time.
9. Select available seats; click one again to deselect. Unavailable sample seats cannot be selected. Explain that this is a UI prototype, not real inventory.
10. Increase adult, child and senior quantities; show their prices and the recalculated total. Select exactly as many seats as tickets. Preview booking displays an explicit prototype notice.
11. Optional: show the countdown starts on selection. Expiry clears the local selection; a new selection starts a new timer. Do not wait five minutes during a short demo unless requested.
12. Show responsive layout and keyboard navigation if time permits. Mobile seat maps scroll horizontally to keep seat buttons usable.

Before presenting: confirm the eLC date/time, at least two attending members, internet/audio, a free port 5001, and the submitted current ZIP or GitHub link. Login, payments, real seat reservations and working date filtering are outside this assignment's explicit Sprint 1 scope.

The assignment's heading says 150 points but its listed categories sum to 170; grading interpretation belongs to the TA.
