import { useNavigate } from 'react-router-dom'
import './MovieCard.css'
import Poster from './Poster'

export default function MovieCard({ movie }) {
  const navigate = useNavigate()

  return (
    <article
      className="mcard"
      onClick={() => navigate(`/movie/${movie.id}`)}
      tabIndex={0}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); navigate(`/movie/${movie.id}`) } }}
      role="button"
      aria-label={`View details for ${movie.title}`}
    >
      <div className="mcard-img">
        <Poster
          src={movie.poster}
          alt={movie.title}
          loading="lazy"

        />
        <div className="mcard-shine" />
        <div className="mcard-overlay">
          <span className="mcard-cta">View details</span>
        </div>
        <span className="mcard-rating tag tag-rating">{movie.rating}</span>
        {movie.status === 'coming_soon' && movie.release_date && (
          <span className="mcard-release">📅 {movie.release_date}</span>
        )}
      </div>

      <div className="mcard-body">
        <div className="mcard-title" title={movie.title}>{movie.title}</div>
        <div className="mcard-meta">
          <span className="tag tag-genre">{movie.genre}</span>
          {movie.status === 'running'
            ? <span className="tag tag-now">Now Showing</span>
            : <span className="tag tag-soon">Coming Soon</span>
          }
        </div>
        {movie.showtimes?.length > 0 && (
          <div className="mcard-showtimes">
            <span className="mcard-showtimes-label">Showtimes</span>
            <div className="mcard-showtime-list">
              {movie.showtimes.map(time => <span key={time} className="mcard-showtime">{time}</span>)}
            </div>
          </div>
        )}
      </div>
    </article>
  )
}
